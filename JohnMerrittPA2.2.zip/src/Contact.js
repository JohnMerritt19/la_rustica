import React, { Component } from "react";
 
class Contact extends Component {
  render() {
    return (
      <div>
        <h2>Contact Us</h2>
        <p>Give us a call (843) 400-2220 or email us! <a href="http://internet.com">here</a>.
        </p>
      </div>
    );
  }
}
 
export default Contact;