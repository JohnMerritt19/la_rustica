import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
      <div>
        <h2>HELLO</h2>
        <p>Rustic Italian Cuisine in the Heart of Historic Summerville</p>
 
        <p>Join us for Happy Hour!</p>
      </div>
    );
  }
}
 
export default Home;